package com.example.cypics;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class Identity_theft extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_identity_theft);
        getSupportActionBar().setTitle("Identity Theft");
    }
}
package com.example.cypics;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class Cyber_terrorism extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cyber_terrorism);
        getSupportActionBar().setTitle("Cyber Terrorism");
    }
}
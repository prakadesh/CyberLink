package com.example.cypics;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class Child_pornography extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_child_pornography);
        getSupportActionBar().setTitle("Child Pornography");

    }
}
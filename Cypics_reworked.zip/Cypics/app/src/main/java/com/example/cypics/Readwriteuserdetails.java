package com.example.cypics;

public class Readwriteuserdetails {
    public String fullname,dob,mob,gender;

    public Readwriteuserdetails(String textfullname,String dateofbirth,String mobile,String textgender){
        this.fullname = textfullname;
        this.dob = dateofbirth;
        this.mob = mobile;
        this.gender = textgender;
    }



}

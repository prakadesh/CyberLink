package com.example.cypics.models

data class Message(
  var message: String,
  var isReceived: Boolean
)

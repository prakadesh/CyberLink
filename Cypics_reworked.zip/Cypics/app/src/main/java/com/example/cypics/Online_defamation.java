package com.example.cypics;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class Online_defamation extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_online_defamation);
        getSupportActionBar().setTitle("Online Defamation");
    }
}
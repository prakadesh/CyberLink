package com.example.cypics;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class Phishing extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_phishing);
        getSupportActionBar().setTitle("Phishing");
    }
}